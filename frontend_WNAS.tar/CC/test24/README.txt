De volgende zaken zijn aangepast
* Er is naast de Klaar knop een Hallo knop gemaakt waarmee een jscall gemaakt kan worden zodat een breakpunt gezet kan worden.
* in de CoreProxy is de referentie naar easyXDM gezet naar een locale easyxdm_cc.js versie. deze is identiek aan de ander versie die op een DCO server staat, maar is door de andere naam in IE8 debu
g tool te ondescheiden van de versie die van de server kant komt.
